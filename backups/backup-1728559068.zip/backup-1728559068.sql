-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: dbattendance
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendance` (
  `attendanceid` int(11) NOT NULL AUTO_INCREMENT,
  `eventid` int(11) NOT NULL,
  `studentid` int(11) NOT NULL,
  `status` enum('in','out') NOT NULL,
  `time_status` enum('morning','afternoon') NOT NULL,
  `semester` tinyint(1) NOT NULL,
  `schoolyear` varchar(10) NOT NULL,
  `dateadded` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`attendanceid`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance`
--

LOCK TABLES `attendance` WRITE;
/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
INSERT INTO `attendance` VALUES (6,5,23,'in','afternoon',1,'2024-2025','2024-09-28 21:15:23'),(7,5,24,'in','afternoon',1,'2024-2025','2024-09-28 21:22:38'),(8,5,25,'in','afternoon',1,'2024-2025','2024-09-28 21:42:04'),(9,5,26,'in','afternoon',1,'2024-2025','2024-09-28 21:46:32'),(10,5,27,'in','afternoon',1,'2024-2025','2024-09-28 22:05:36'),(11,5,25,'out','afternoon',1,'2024-2025','2024-09-28 22:45:14'),(12,5,27,'out','afternoon',1,'2024-2025','2024-09-28 22:46:47'),(13,5,24,'out','afternoon',1,'2024-2025','2024-09-28 22:56:13'),(14,5,23,'out','afternoon',1,'2024-2025','2024-09-28 23:05:49'),(15,5,26,'out','afternoon',1,'2024-2025','2024-09-28 23:08:27'),(16,6,26,'in','afternoon',1,'2024-2025','2024-10-02 20:23:31'),(17,6,23,'in','afternoon',1,'2024-2025','2024-10-02 20:23:53'),(18,6,25,'in','afternoon',1,'2024-2025','2024-10-02 20:24:53'),(19,7,24,'in','morning',1,'2024-2025','2024-10-05 09:39:40'),(20,7,25,'in','morning',1,'2024-2025','2024-10-05 09:39:59'),(21,8,27,'in','afternoon',1,'2024-2025','2024-10-05 21:42:32'),(22,8,24,'in','afternoon',1,'2024-2025','2024-10-05 21:44:04'),(23,8,29,'in','afternoon',1,'2024-2025','2024-10-05 21:44:42');
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup`
--

DROP TABLE IF EXISTS `backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup` (
  `backupid` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `backup_date` datetime NOT NULL,
  `schoolyear` varchar(10) NOT NULL,
  PRIMARY KEY (`backupid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup`
--

LOCK TABLES `backup` WRITE;
/*!40000 ALTER TABLE `backup` DISABLE KEYS */;
INSERT INTO `backup` VALUES (3,'backup-1727527836.zip','2024-09-28 20:50:37','2024-2025'),(4,'backup-1727575282.zip','2024-09-29 10:01:22','2024-2025'),(5,'backup-1727664463.zip','2024-09-30 10:47:44','2024-2025'),(6,'backup-1727782237.zip','2024-10-01 19:30:38','2024-2025'),(7,'backup-1727871652.zip','2024-10-02 20:20:53','2024-2025'),(8,'backup-1728090959.zip','2024-10-05 09:15:59','2024-2025'),(9,'backup-1728394154.zip','2024-10-08 21:29:14','2024-2025'),(10,'backup-1728442497.zip','2024-10-09 10:54:57','2024-2025');
/*!40000 ALTER TABLE `backup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course` (
  `courseid` int(11) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(150) NOT NULL,
  `departmentid` int(11) NOT NULL,
  PRIMARY KEY (`courseid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (1,'BSIT',1);
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `departmentid` int(11) NOT NULL AUTO_INCREMENT,
  `department_name` varchar(150) NOT NULL,
  PRIMARY KEY (`departmentid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES (1,'CITCS');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event` (
  `eventid` int(11) NOT NULL AUTO_INCREMENT,
  `event_name` varchar(150) NOT NULL,
  `event_place` varchar(150) NOT NULL,
  `event_start_date` date NOT NULL,
  `event_end_date` date NOT NULL,
  `event_starttime_am` time NOT NULL,
  `event_endtime_am` time NOT NULL,
  `event_starttime_pm` time NOT NULL,
  `event_endtime_pm` time NOT NULL,
  `event_starttime_am_in` time NOT NULL,
  `event_endtime_am_in` time NOT NULL,
  `event_starttime_am_out` time NOT NULL,
  `event_endtime_am_out` time NOT NULL,
  `event_starttime_pm_in` time NOT NULL,
  `event_endtime_pm_in` time NOT NULL,
  `event_starttime_pm_out` time NOT NULL,
  `event_endtime_pm_out` time NOT NULL,
  `status` enum('wholeday','morning','afternoon') NOT NULL,
  `semester` tinyint(1) NOT NULL,
  `schoolyear` varchar(10) NOT NULL,
  PRIMARY KEY (`eventid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` VALUES (5,'Intrams','QSU','2024-09-28','2024-09-28','00:00:00','00:00:00','21:15:00','23:45:00','00:00:00','00:00:00','00:00:00','00:00:00','21:15:00','22:15:00','22:45:00','23:45:00','afternoon',1,'2024-2025'),(6,'test','QSU','2024-10-02','2024-10-02','00:00:00','00:00:00','20:00:00','22:00:00','00:00:00','00:00:00','00:00:00','00:00:00','20:00:00','21:00:00','21:00:00','22:00:00','afternoon',1,'2024-2025'),(7,'Testing','QSU','2024-10-05','2024-10-05','09:00:00','12:00:00','13:00:00','14:00:00','09:00:00','10:00:00','10:00:00','11:00:00','15:00:00','16:00:00','15:00:00','16:00:00','morning',1,'2024-2025'),(8,'testing dash','QSU','2024-10-05','2024-10-05','00:00:00','00:00:00','21:00:00','23:00:00','00:00:00','00:00:00','00:00:00','00:00:00','21:00:00','22:00:00','22:00:00','23:00:00','afternoon',1,'2024-2025');
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_officer`
--

DROP TABLE IF EXISTS `event_officer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_officer` (
  `eventid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `days` varchar(100) NOT NULL,
  `status` enum('wholeday','morning','afternoon') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_officer`
--

LOCK TABLES `event_officer` WRITE;
/*!40000 ALTER TABLE `event_officer` DISABLE KEYS */;
INSERT INTO `event_officer` VALUES (5,5,'1','afternoon'),(6,5,'1','afternoon'),(7,5,'1','morning'),(8,5,'1','afternoon');
/*!40000 ALTER TABLE `event_officer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sanction`
--

DROP TABLE IF EXISTS `sanction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sanction` (
  `sanction_id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `no_of_absences` tinyint(2) NOT NULL,
  PRIMARY KEY (`sanction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sanction`
--

LOCK TABLES `sanction` WRITE;
/*!40000 ALTER TABLE `sanction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sanction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `studentid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(150) NOT NULL,
  `middlename` varchar(150) NOT NULL,
  `lastname` varchar(150) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `image` varchar(70) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`studentid`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (23,'Syvhell','Abad','Umila','0955632672','61c6b8d4ec41f6b6cf916a9befd83630.png','2024-09-28 20:55:42'),(24,'Joan','Hermons','Daigo','0955632672','ac2750169699da41097df7343699126b.png','2024-09-28 20:56:43'),(25,'Added','Added','Added','0955632672','430d4ffb999608c0f62464297d199633.png','2024-09-28 21:40:25'),(26,'Added1','Added1','Added1','0955632672','b5f2137a6596ad14f206990cc3dc653e.png','2024-09-28 21:45:06'),(27,'Added2','Added2','Added2','0955632672','51b9fd05a9299161b2e45d2b9a23b589.png','2024-09-28 21:54:28'),(28,'Syvhellss','Abadss','Umilass','0955632672','c432f9ca882c18ec5e764583a2cfa981.png','2024-10-05 10:15:56'),(29,'Syvhellr','Abadr','Umilar','0955632672','ae6de01b4f4b5388530b01677418892d.png','2024-10-05 21:35:10'),(30,'Syvhellt','Abadt','Umilat','0955632672','274ba3b9ee7095612724d83cf02cb6b9.png','2024-10-05 21:35:40'),(31,'Syvhellg','Abadg','Umilag','0955632672','5690357e5012c3c43812885043dc06a4.png','2024-10-05 21:58:39');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_academic_details`
--

DROP TABLE IF EXISTS `student_academic_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_academic_details` (
  `studentacademicdetailid` int(11) NOT NULL AUTO_INCREMENT,
  `studentid` int(11) NOT NULL,
  `courseid` int(11) NOT NULL,
  `year` tinyint(1) NOT NULL,
  `section` varchar(5) NOT NULL,
  `schoolyear` varchar(10) NOT NULL,
  PRIMARY KEY (`studentacademicdetailid`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_academic_details`
--

LOCK TABLES `student_academic_details` WRITE;
/*!40000 ALTER TABLE `student_academic_details` DISABLE KEYS */;
INSERT INTO `student_academic_details` VALUES (23,23,1,1,'F','2024-2025'),(24,24,1,2,'A','2024-2025'),(25,25,1,1,'F','2024-2025'),(26,26,1,1,'F','2024-2025'),(27,27,1,2,'F','2024-2025'),(28,28,1,4,'SADF','2024-2025'),(29,29,1,2,'F','2024-2025'),(30,30,1,2,'F','2024-2025'),(31,23,1,2,'F','2024-2025'),(32,24,1,3,'A','2024-2025'),(33,25,1,2,'F','2024-2025'),(34,26,1,2,'F','2024-2025'),(35,27,1,3,'F','2024-2025'),(36,29,1,3,'F','2024-2025'),(37,30,1,3,'F','2024-2025'),(38,31,1,3,'C','2024-2025');
/*!40000 ALTER TABLE `student_academic_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_barcode`
--

DROP TABLE IF EXISTS `student_barcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_barcode` (
  `studentid` int(11) NOT NULL,
  `barcode` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_barcode`
--

LOCK TABLES `student_barcode` WRITE;
/*!40000 ALTER TABLE `student_barcode` DISABLE KEYS */;
INSERT INTO `student_barcode` VALUES (23,'18105555'),(24,'10203040'),(25,'11223344'),(26,'55667788'),(27,'00998877'),(28,'18-10577'),(29,'18-10579'),(30,'00-00000'),(31,'18-1057745');
/*!40000 ALTER TABLE `student_barcode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_yearlevel_update`
--

DROP TABLE IF EXISTS `student_yearlevel_update`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_yearlevel_update` (
  `studentyearlevelupdateid` int(11) NOT NULL AUTO_INCREMENT,
  `schoolyear` varchar(10) NOT NULL,
  PRIMARY KEY (`studentyearlevelupdateid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_yearlevel_update`
--

LOCK TABLES `student_yearlevel_update` WRITE;
/*!40000 ALTER TABLE `student_yearlevel_update` DISABLE KEYS */;
INSERT INTO `student_yearlevel_update` VALUES (2,'2024-2025');
/*!40000 ALTER TABLE `student_yearlevel_update` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(64) NOT NULL,
  `firstname` varchar(150) NOT NULL,
  `middlename` varchar(150) NOT NULL,
  `lastname` varchar(150) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `image` varchar(70) NOT NULL,
  `position` enum('admin','officer') NOT NULL DEFAULT 'officer',
  `position_description` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `isdeleted` tinyint(1) NOT NULL,
  `semester` tinyint(1) NOT NULL,
  `schoolyear` varchar(10) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','8ead58753335bb936bac6033b400c7f6f61f36ebc10660883de78ce070efe75a','Admin','Admin','Admin','1234567890','6ca9adb48926f04929b1b351a9f7275c.jpeg','admin','System Administrator','2018-02-07 21:41:16',0,0,''),(5,'Zye','4132cddf9f1cffbc83d268c4e86c2b54e34e431265997c532175b9274d68dfbc','Zye','Abad','Umila','0955632672','920ed68bed1f342dec1098a9c1c3b8c5.png','officer','Scanner','2024-09-28 20:57:20',0,1,'2024-2025');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_log`
--

DROP TABLE IF EXISTS `user_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_log` (
  `userlogid` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `description` varchar(500) NOT NULL,
  `datelog` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`userlogid`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_log`
--

LOCK TABLES `user_log` WRITE;
/*!40000 ALTER TABLE `user_log` DISABLE KEYS */;
INSERT INTO `user_log` VALUES (68,4,'Logged Out','2024-09-28 20:50:39'),(69,1,'Logged In','2024-09-28 20:50:49'),(70,1,'Logged Out','2024-09-28 21:00:35'),(71,5,'Logged In','2024-09-28 21:00:45'),(72,5,'Logged Out','2024-09-28 21:10:43'),(73,1,'Logged In','2024-09-28 21:10:54'),(74,1,'Logged Out','2024-09-28 21:14:52'),(75,5,'Logged In','2024-09-28 21:14:58'),(76,5,'Logged Out','2024-09-28 22:42:37'),(77,1,'Logged In','2024-09-28 22:42:48'),(78,1,'Logged Out','2024-09-28 22:43:34'),(79,5,'Logged In','2024-09-28 22:43:44'),(80,5,'Logged In','2024-09-30 10:48:18'),(81,5,'Logged Out','2024-09-30 10:49:07'),(82,1,'Logged In','2024-10-01 19:31:00'),(83,1,'Logged In','2024-10-02 20:21:01'),(84,1,'Logged Out','2024-10-02 20:23:03'),(85,5,'Logged In','2024-10-02 20:23:15'),(86,1,'Logged In','2024-10-02 22:16:32'),(87,1,'Logged Out','2024-10-02 22:16:56'),(88,5,'Logged In','2024-10-02 22:17:03'),(89,5,'Logged Out','2024-10-02 22:17:07'),(90,5,'Logged In','2024-10-02 22:17:48'),(91,5,'Logged In','2024-10-05 09:16:14'),(92,5,'Logged Out','2024-10-05 09:36:41'),(93,1,'Logged In','2024-10-05 09:36:55'),(94,1,'Logged Out','2024-10-05 09:38:59'),(95,5,'Logged In','2024-10-05 09:39:07'),(96,5,'Logged Out','2024-10-05 10:18:07'),(97,1,'Logged In','2024-10-05 10:18:15'),(98,1,'Logged Out','2024-10-05 10:19:37'),(99,5,'Logged In','2024-10-05 10:19:52'),(100,5,'Logged Out','2024-10-05 21:35:45'),(101,1,'Logged In','2024-10-05 21:35:55'),(102,1,'Logged Out','2024-10-05 21:37:07'),(103,5,'Logged In','2024-10-05 21:37:11'),(104,5,'Logged Out','2024-10-05 21:53:28'),(105,1,'Logged In','2024-10-05 21:53:32'),(106,1,'Logged Out','2024-10-05 21:59:37'),(107,1,'Logged In','2024-10-05 21:59:44');
/*!40000 ALTER TABLE `user_log` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-10 19:17:48
